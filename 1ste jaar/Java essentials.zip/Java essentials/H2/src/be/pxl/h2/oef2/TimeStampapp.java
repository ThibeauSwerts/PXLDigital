package be.pxl.h2.oef2;

import be.pxl.h2.RechthoekApp.Rechthoek;

public class TimeStampapp {
    public static void main(String[] args)
    {
        TimeStamp time1 = new TimeStamp(840);
        TimeStamp time2 = new TimeStamp(840);
        TimeStamp time3 = new TimeStamp(time2);

    }
}
