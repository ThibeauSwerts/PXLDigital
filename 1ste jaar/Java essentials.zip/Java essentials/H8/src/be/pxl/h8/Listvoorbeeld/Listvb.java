package be.pxl.h8.Listvoorbeeld;

import java.util.ArrayList;

public class Listvb {
    public static void main(String[] args) {
        ArrayList<Persoon> lijst = new ArrayList<>();

        String s = "q4124";
        Persoon p = new Persoon();
        Student st = new Student();
        lijst.add(p);
        lijst.add(st);

        ArrayList<Integer>intList = new ArrayList<>();
    }
}
