package be.pxl.h8.Listvoorbeeld;

public class Student extends Persoon{
}
