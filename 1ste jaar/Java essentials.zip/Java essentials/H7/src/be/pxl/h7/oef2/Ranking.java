package be.pxl.h7.oef2;

public enum Ranking {
    TWEE, DRIE, VIER, VIJF, ZES, ZEVEN, ACHT, NEGEN, TIEN, BOER, DAME, KONING, AAS;
}
