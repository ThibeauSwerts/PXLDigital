package be.pxl.h7.oef2;

public enum Soort {
    HARTEN, RUITEN, KLAVEREN, SCHOPPEN;
}
