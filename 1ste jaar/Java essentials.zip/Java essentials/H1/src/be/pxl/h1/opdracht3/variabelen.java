package be.pxl.h1.opdracht3;

public class variabelen {

    public static void main(String[] args) {

        boolean boel = true; //in java met lowers
        char letter = 'x'; //enkel met '' voor chars, "" is voor strings
        long groot_getal = 511L;
        double pi = 3.14159;

        System.out.println(boel);
        System.out.println("het karakter is " + letter);

    }
}
