package be.pxl.h1.xhelloworld;

// author: sandro barilla

public class HelloWorld {

    public static void main(String[] args) {

        System.out.println("Hello there!");
        System.out.println("General kenobi!");
        System.out.println("dit is, in fact, mijn eerste java programma");
    }
}
