﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace House_Demo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {// volgende instantieeigenschappen nodig om properties te kunnen wijzigen
       // in de eventhandler van de slider
        private Line horizontalLine;
        private Line verticalLine;
        private Line otherLine;
        private Rectangle rectangle;
        public MainWindow()
        {
            InitializeComponent();
            // standaard staat de minimale waarde van de slider op 0 en de maximale waarde op 10
            //xSlider.Maximum = paperCanvas.Width - 50;
            // zorgen dat de slider recht onder de top van het dak staat
            //xSlider.Width = paperCanvas.Width - 50;
            // huisje moet 10 posities van linkerrand en rechterrand blijven
            xSlider.Minimum = 10; // linkerrand
            xSlider.Maximum = paperCanvas.Width - 60;
            xSlider.Width = paperCanvas.Width - 60;
            // zorgt voor problemen instellen op 10 => eventhandler wordt opgeroepen
            // oplossing eventhandler hier pas koppelen

            xSlider.ValueChanged += xSlider_ValueChanged;
        }

        private void drawButton_Click(object sender, RoutedEventArgs e)
        {
            SolidColorBrush blackBrush = new SolidColorBrush(Colors.Black);

            DrawHouse(paperCanvas, blackBrush, 60, 40, 50, 50);
            drawButton.IsEnabled = false;
            xSlider.IsEnabled = true;
            xSlider.Value = 60;
        }

        private void DrawHouse(Canvas drawingArea,
                               SolidColorBrush brushToUse,
                               double topRoofX,
                               double topRoofY,
                               double width,
                               double height)
        {
            DrawTriangle(drawingArea, brushToUse, topRoofX,
                         topRoofY, width, height);
            DrawRectangle(drawingArea, brushToUse, topRoofX,
                          topRoofY + height, width, height, out rectangle);
        }

        private void DrawTriangle(Canvas drawingArea,
                                  SolidColorBrush brushToUse,
                                  double topX,
                                  double topY,
                                  double width,
                                  double height)
        {
            DrawLine(drawingArea, brushToUse, topX, topY,
                     topX, topY + height, out verticalLine);
            DrawLine(drawingArea, brushToUse, topX,
                     topY + height,
                     topX + width, topY + height,out horizontalLine );
            DrawLine(drawingArea, brushToUse, topX, topY,
                     topX + width, topY + height, out otherLine);
        }

        private void DrawLine(Canvas drawingArea,
                              SolidColorBrush brushToUse,
                              double startX, double startY,
                              double endX, double endY, out Line theLine)
        {
            theLine = new Line();
            theLine.X1 = startX; theLine.X2 = endX;
            theLine.Y1 = startY; theLine.Y2 = endY;
            theLine.Stroke = brushToUse;
            theLine.StrokeThickness = 1;
            drawingArea.Children.Add(theLine);
        }

        private void DrawRectangle(Canvas drawingArea,
                                   SolidColorBrush brushToUse,
                                   double topLeftX,
                                   double topLeftY,
                                   double width,
                                   double height, out Rectangle theRectangle)
        {
            theRectangle = new Rectangle();
            theRectangle.Width = width;
            theRectangle.Height = height;
            theRectangle.Margin = new Thickness(topLeftX, topLeftY, 0, 0);
            theRectangle.Stroke = brushToUse;
            drawingArea.Children.Add(theRectangle);
        }
        private void UpDateHouse(double topX)
        {
            horizontalLine.X1 = topX; horizontalLine.X2 = topX + 50;
            verticalLine.X1 = topX; verticalLine.X2 = topX;
            otherLine.X1 = topX; otherLine.X2 = topX + 50;
            rectangle.Margin = new Thickness(topX, 90, 0, 0);
        }

        private void xSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            UpDateHouse(xSlider.Value);
            positionLabel.Content = $"x position of the roof {xSlider.Value}";
        }
    }
}
