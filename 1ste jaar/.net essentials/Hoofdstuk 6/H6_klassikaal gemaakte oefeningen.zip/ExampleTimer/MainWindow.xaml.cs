﻿using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace ExampleTimer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Ellipse circle;
        // elke seconde moet er een cirkel verschijnen nadat je op de drawButton geklikt hebt
        private DispatcherTimer timer;
        private int countSeconds = 0; // om aantal seconden te tellen

        public MainWindow()
        {
            InitializeComponent();
            CreateEllipse();
            timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(1) // snelheid waarmee timer tikt
            };
            timer.Tick += Timer_Tick;

        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            UpdateEllipse();
            countSeconds += 1;
        }

        private void CreateEllipse()
        {
            circle = new Ellipse
            {   
                Stroke = new SolidColorBrush(Colors.Blue),
                Fill = new SolidColorBrush(Colors.Blue),
                Visibility = Visibility.Hidden
            };
            paperCanvas.Children.Add(circle);
          
        }

        private void UpdateEllipse()
        {
            Random random = new Random();
            // x, y van de linkerbovenhoek random genereren
            int x = random.Next(0, Convert.ToInt32(paperCanvas.Width));
            int y = random.Next(0, Convert.ToInt32(paperCanvas.Height));
            circle.Margin = new Thickness(x, y, 0, 0);
            // straal >=1 en <= 100 random genereren
            int diameter = random.Next(2, 201);
            circle.Width = diameter;
            circle.Height = diameter;

        }
        private void drawButton_Click(object sender, RoutedEventArgs e)
        {
            UpdateEllipse();
            circle.Visibility = Visibility.Visible;
            timer.Start();
        }

        private void removeButton_Click(object sender, RoutedEventArgs e)
        {
            circle.Visibility = Visibility.Hidden;
            timer.Stop();
            // bij stoppen van timer in MessageBox tonen hoeveel seconden er zijn
            // tussen het starten en stoppen
            MessageBox.Show($"het aantal seconden tussen start en stop {countSeconds}");
            countSeconds = 0;
        }
    }
}
