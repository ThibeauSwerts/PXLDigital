﻿using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;

namespace ExampleRandom
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Ellipse circle;

        public MainWindow()
        {
            InitializeComponent();
            CreateEllipse();
        }

        private void CreateEllipse()
        {
            circle = new Ellipse
            {   
                Stroke = new SolidColorBrush(Colors.Blue),
                Fill = new SolidColorBrush(Colors.Blue),
                Visibility = Visibility.Hidden
            };
            paperCanvas.Children.Add(circle);
          
        }

        private void UpdateEllipse()
        {
            Random random = new Random();
            // x, y van de linkerbovenhoek random genereren
            int x = random.Next(0, Convert.ToInt32(paperCanvas.Width));
            int y = random.Next(0, Convert.ToInt32(paperCanvas.Height));
            circle.Margin = new Thickness(x, y, 0, 0);
            // straal >=1 en <= 100 random genereren
            int diameter = random.Next(2, 201);
            circle.Width = diameter;
            circle.Height = diameter;

        }
        private void drawButton_Click(object sender, RoutedEventArgs e)
        {
            UpdateEllipse();
            circle.Visibility = Visibility.Visible;
        }

        private void removeButton_Click(object sender, RoutedEventArgs e)
        {
            circle.Visibility = Visibility.Hidden;
        }
    }
}
