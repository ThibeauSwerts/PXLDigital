﻿using System;
using System.Windows;

namespace Dice
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            // 1 eventhandler voor beide sliders
            slider1.ValueChanged += slider_ValueChanged;
            slider2.ValueChanged += slider_ValueChanged; 
            CheckValues(slider1.Value, slider2.Value);
        }


        private void slider_ValueChanged(object sender,
                               RoutedPropertyChangedEventArgs<double> e)
        {
            CheckValues(slider1.Value, slider2.Value);
        }


       
        private void CheckValues(double x, double y)
        {
            int die1 = Convert.ToInt32(x);
            int die2 = Convert.ToInt32(y);
            int total = die1 + die2;
            totalLabel.Content = $"total is {total}";

            if (total == 6)
            {
                statusLabel.Content = "You have won";
            }
            else
            {
                statusLabel.Content = "You have lost";
            }
        }

      
    }
}
