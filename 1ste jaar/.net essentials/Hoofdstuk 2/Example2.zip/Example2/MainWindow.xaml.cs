﻿using System;
using System.Windows;

namespace Example2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        // klikken op button Click => text in label
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            outputLabel.Content = "Hello 1TING";
        }
        // klikken op messageButton => berichten venster openen
        private void messageButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Hello again 1TING", "Title TING");
            // boodschap afprinten in de console (sout in Java)
            Console.WriteLine("Hello is almost time to stop");
        }
    }
}
