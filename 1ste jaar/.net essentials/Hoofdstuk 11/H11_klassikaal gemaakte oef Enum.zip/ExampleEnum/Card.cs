﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExampleEnum
{   public enum RankType { Two, Three, Four, Five, Six, Seven, Eight, Nien, Ten, Jack, Queen, King, Ace}
    public enum SuitType { Clubs='C', Spades='S', Diamonds='D', Hearts='H'}
    public class Card
    {
        public RankType Rank { get; set; }
        public SuitType Suit { get; set; }

        public override string ToString()
        {
            return $" Rank {Rank} Suit {Suit}";
        }
        Enum
        // voor extra methoden zie klasse Enum bvb array opvragen van alle elementen in de enum
    }
}
