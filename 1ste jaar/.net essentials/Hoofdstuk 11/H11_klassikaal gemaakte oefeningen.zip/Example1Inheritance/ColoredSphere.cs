﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace Example1Inheritance
{
    public class ColoredSphere : Sphere
    {
        private SolidColorBrush _brush;
        // kleur moet kunnen aangepast worden
        public SolidColorBrush Brush // write only property
        {   private get => _brush;
            set { _brush = value; UpdateEllipse(); }
        }

        public ColoredSphere(int x, int y, SolidColorBrush brush) : base(x, y, 20) // super in Java
        {
            Brush = brush; // UpdateEllipse wordt gedaan zie code Bij de property
          
        }

        private void UpdateEllipse()
        {
            _ellipse.Fill = Brush;
            _ellipse.Stroke = Brush;
        }
        // methode Move overschrijven => gekleurde cirkel mag alleen naar boven bewegen
        public override void Move()
        {
            _y -= 5;
            _ellipse.Margin = new Thickness(_x, _y, 0, 0);
        }
    }
}
