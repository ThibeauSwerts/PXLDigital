﻿using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows;

namespace Example1Inheritance
{
    public class Sphere
    {
        protected int _x ; // protected => toegankelijk in alle overervende klassen
        protected int _y ; // geen accessmodifier = private
        protected Ellipse _ellipse;
        protected double _radius;

        // constructor met 3 parameters
        public Sphere(int x, int y, double radius)
        {
            _x = x; _y = y; _radius = radius;
            CreateEllipse();
        }
      
        public void CreateEllipse()
        {
            _ellipse = new Ellipse()
            {
                Stroke = new SolidColorBrush(Colors.Black),
                StrokeThickness = 2,
                Width = 2 * _radius,
                Height = 2 * _radius,
                Margin = new Thickness(_x, _y, 0, 0)
            };
           
        }

        public void DisplayOnCanvas(Canvas drawingCanvas)
        {
            drawingCanvas.Children.Add(_ellipse);
        }

       // methode Mowe 5 pixels naar rechts en 5 pixels naar beneden
       public virtual void Move() // virtual = methode mag overschreven worden
        {
            _x += 5; _y += 5;
            _ellipse.Margin = new Thickness(_x, _y, 0, 0);
        }
    }
}
