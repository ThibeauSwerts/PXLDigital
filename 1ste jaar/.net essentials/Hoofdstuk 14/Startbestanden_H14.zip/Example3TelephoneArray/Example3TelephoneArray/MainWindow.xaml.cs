﻿using System.Windows;

namespace Example3TelephoneArray
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string[] names = { "An", "Piet", "Jan", "Mo", "Eray", "Cindy", "Mark", "Semih", "Kathleen", "Jari" };
        private string[] numbers =
            { "0472151698", "0476895896", "011548967", "012457896", "0478596836", "0472345678", "013464545", "011788966", "0478455469", "011234569"};


        public MainWindow()
        {
            InitializeComponent();

        }

        private void FindButton_Click(object sender, RoutedEventArgs e)
        {

        }


    }
}
