﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MouseMove
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Canvas_MouseMove(object sender, MouseEventArgs e)
        {
            // positie van de muis tov het Canvas
            Point position = e.GetPosition(drawCanvas);
            positionCanvasTextBlock.Text = "X: " + position.X + " Y: " + position.Y;
            // positie van de muis tov mainWindow
            Point position1 = e.GetPosition(this);
            positionMainWindowTextBlock.Text = "X: " + position1.X + " Y: " + position1.Y;
        }
    }
}
