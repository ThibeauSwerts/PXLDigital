﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SecondDrawingBis
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    { // extra button disappear, bij klikken op draw => teken van rechthoeken
        // bij klikken op disappear => rechtheoken worden niet getoond
      // manier 2 door deze rechthoeken aan te maken in XAML

        public MainWindow()
        {
            InitializeComponent();
            lowerRectangle.Visibility = Visibility.Hidden;
            upperRectangle.Visibility = Visibility.Hidden;
            logoImage.Visibility = Visibility.Hidden;
        }

        private void drawButton_Click(object sender, RoutedEventArgs e)
        {
            lowerRectangle.Visibility = Visibility.Visible;
            upperRectangle.Visibility = Visibility.Visible;
            logoImage.Visibility = Visibility.Visible;
        }

        private void disappearButton_Click(object sender, RoutedEventArgs e)
        {
            lowerRectangle.Visibility = Visibility.Hidden;
            upperRectangle.Visibility = Visibility.Hidden;
            logoImage.Visibility = Visibility.Hidden;
        }
    }
}
