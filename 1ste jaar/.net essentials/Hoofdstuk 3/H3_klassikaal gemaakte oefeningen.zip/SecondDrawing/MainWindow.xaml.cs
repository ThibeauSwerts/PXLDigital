﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SecondDrawing
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    { // extra button disappear, bij klikken op draw => teken van rechthoeken
        // bij klikken op disappear => rechtheoken worden niet getoond
        private Rectangle upperRectangle;
        private Rectangle lowerRectangle;

        public MainWindow()
        {
            InitializeComponent();
            upperRectangle = new Rectangle
            {
                Width = 100, // breedte
                Height = 50, // hoogte
                Margin = new Thickness(10, 10, 0, 0), // plaats
                Stroke = new SolidColorBrush(Colors.Black), // kleur
                StrokeThickness = 3, // dikte lijn
                Fill = new SolidColorBrush(Colors.Red), // opvulkleur
                Visibility = Visibility.Hidden
            };
            paperCanvas.Children.Add(upperRectangle);
            lowerRectangle = new Rectangle
            {
                Width = 100,
                Height = 100,
                Margin = new Thickness(10, 75, 0, 0),
                Stroke = new SolidColorBrush(Colors.Black),
                Visibility = Visibility.Hidden
            };
            paperCanvas.Children.Add(lowerRectangle);

        }

        private void drawButton_Click(object sender, RoutedEventArgs e)
        {
            lowerRectangle.Visibility = Visibility.Visible;
            upperRectangle.Visibility = Visibility.Visible;
        }

        private void disappearButton_Click(object sender, RoutedEventArgs e)
        {
            lowerRectangle.Visibility = Visibility.Hidden;
            upperRectangle.Visibility = Visibility.Hidden;
        }
    }
}
