﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Triangle
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
// leesbaardere code
// 1. zorg voor zinvolle namen
// 2. commentaar zetten
// 3. methoden gebruiken
        private void drawButton_Click(object sender, RoutedEventArgs e)
        {
            // draw a triangle
            
            SolidColorBrush brushToUse = new SolidColorBrush(Colors.Black);
            DrawTriangle(paperCanvas, brushToUse, 20, 80, 70, 10, 120, 80);


        }
        private void DrawTriangle(Canvas canvas, SolidColorBrush brushToUse, int x1, int y1, 
            int x2, int y2, int x3, int y3)
        {
            // first line
          
            DrawLine(paperCanvas, brushToUse, x1, y1, x2, y2);

            // second line
            DrawLine(paperCanvas, brushToUse, x2, y2, x3, y3);

            // third line
            DrawLine(paperCanvas, brushToUse, x3, y3, x1, y1);
        }

        private void DrawLine(Canvas paperCanvas, SolidColorBrush brush,
            int startX, int startY, int eindX, int eindY)
        {
            Line line = new Line();
            line.X1 = startX; line.Y1 = startY;
            line.X2 = eindX; line.Y2 = eindY;
            line.Stroke = brush;
            paperCanvas.Children.Add(line); 
        }
    }
}
