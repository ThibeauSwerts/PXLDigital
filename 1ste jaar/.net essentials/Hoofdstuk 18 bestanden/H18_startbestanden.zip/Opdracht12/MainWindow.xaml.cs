﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Opdracht12
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml7 
    /// oefeing 18.7
    /// FolderBrowserDialog wordt niet ondersteund door WPF, daarom moet je teruggaan
    /// naar de WinForms versie, zie ook:
    /// http://stackoverflow.com/questions/1922204/open-directory-dialog
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
