﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ReadingWrting
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private FileStream fstream;
        private StreamReader reader;
        private StreamWriter writer;

        public MainWindow()
        {
            InitializeComponent();
            // test.txt bevindt zich in ReadingWriting\bin\Debug
            fstream = new FileStream("test.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            writer = new StreamWriter(fstream);
            reader = new StreamReader(fstream);
        }

        private void ReadButton_Click(object sender, RoutedEventArgs e)
        {   
            textTextBox.Text = reader.ReadToEnd();
            
        }

        private void WriteButton_Click(object sender, RoutedEventArgs e)
        {
            if (textTextBox.Text != "")
            {   
                writer.WriteLine("begin");
                writer.WriteLine(textTextBox.Text);
                writer.WriteLine("einde");
            }
        }
      

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            writer.Close();  //maar 1 van beide  afsluiten van writer => fstream afgesloten
            // reader is dan ook afgesloten
            //reader.Close();
        }
    }
}
