﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BalloonApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Balloon balloon1;
        private Balloon balloon2;
        
        public MainWindow()
        {
            InitializeComponent();

            balloon1 = new Balloon();
            // wijzig y in 80 en diameter in 20
            balloon1.Y = 80; balloon1.Diameter = 20;
           // balloon1.Name = "eerste ballon"; zie opdracht XX
           
            balloon1.ChangeColor(Colors.Red);
            // alternatieve manier
            balloon1.Color = Colors.PeachPuff;
            // 2de ballon x=150, y=20, diameter = 60
            balloon2 = new Balloon(150, 20, 60);
            UpdateTextBox();
            balloon1.DisplayOn(drawingCanvas);
            balloon2.DisplayOn(drawingCanvas);
        }
        private void UpdateTextBox()
        {// probleem tekst geraakt niet in de textblock
            outputTextBox.Text = $"de ballon ({balloon1.Name}) bevindt zich op positie ({balloon1.X}, {balloon1.Y}) " +
                $"met een oppervlakte {balloon1.Area:F2} \n" +
                $"de ballon({ balloon2.Name}) bevindt zich op positie({ balloon2.X}, { balloon2.Y}) " +
                $"met een oppervlakte {balloon2.Area:F2} "; // handboek p 81 - p 308
        }
        private void moveButton_Click(object sender, RoutedEventArgs e)
        {
            balloon1.MoveRight(20);
            // 2de ballon beweegt 10 pixels naar links
            balloon2.MoveRight(-10);
            UpdateTextBox();
        }

        private void growButton_Click(object sender, RoutedEventArgs e)
        {
            balloon1.ChangeSize(20);
            UpdateTextBox();
        }

        private void countButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show($"de methode MoveRight werd {Balloon.CountMoveRight} keer opgeroepen");
        }
    }
}
