﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace BalloonApp
{
    public class Balloon
    {   // instantie eigenschappen
        private int x = 50; // private  data hiding = encapsulation
        private int y = 50;
        private int diameter = 20;
        private Ellipse ellipse;
        private SolidColorBrush brush = new SolidColorBrush(Colors.Blue);
        // klasse variable
        //private static int countMoveRight; // telt hoe vaak de methode MoveRight wert opgeroepen
        // opgave xx: bij aanmaken van een ballon moet de ballon automatisch een naam krijgen
        // de eerste ballon01, de 2de ballon02, ....
        private static int count; // om te tellen hoeveel ballonnen er zijn
        // getters en setters in Java => properties
        // NOOIT een setter of getter gebruiken zoals in Java
        public int X
        {
            get { return x; }
            set { x = value; UpdateEllipse(); }
        }
        public int Y
        {
            get => y; // lambdaoperator
            set { y = value; UpdateEllipse(); }
        }
        // diameter alleen van waarde veranderd kan worden,
        // waarde mag niet opgevraag kunnen worden in een andere klasse
        // write only property (alleen een setter)
        public int Diameter
        {
            private get => diameter; // getter kan gebruikt worden in deze klasse niet buiten deze klasse
            set { diameter = value; UpdateEllipse(); }
        }
        // read only property (alleen een getter)
        public double Area => CalculateArea(); 
        // autoproperty (= property zonder zelf een instantie eigenschap aan te maken)
        // public string Name { get; set; }
        // zie opdracht XX niemand mag de naam kunnen wijzigen
        public string Name { get; }
        // zonder private set kan je deze Name alleen een waarde geven in de constructor
        // met private set overal in deze klasse
        // property om de kleur te wijzigen (alleen set nodig) => write only
        public Color Color { set { brush.Color = value; } }
        // klasse property om aantalkeer dat de methode MoveRight wert opgeroepen terug te geven
        //public static int CountMoveRight => countMoveRight;
        // Kan het voorgaande met een autoproperty?
        public static int CountMoveRight { get; private set; }
        


        // constructor: methode om een object aan te maken +
        // initialiseert de instantie eigenschappen
        // meerdere constructors in dezelfde klasse = constructor overloading
        //public Balloon()
        //{
        //    CreateEllipse();
        //    UpdateEllipse();
        //}

        //public Balloon(int initialX): this(initialX, 50, 20)
        //    // in constructor een andere constructor oproepen 
        //{
        //}

        //public Balloon(int initialX, int initialY)
        //{
        //    x = initialX;
        //    y = initialY;
        //    CreateEllipse();
        //    UpdateEllipse();
        //}

        //public Balloon(int initialX,
        //               int initialY,
        //               int initialDiameter)
        //{
        //    x = initialX;
        //    y = initialY;
        //    diameter = initialDiameter;

        //    CreateEllipse();
        //    UpdateEllipse();
        //} voorgaande kan eenvoudiger 
        // oplossing 1 constructor met optionele parameters
        public Balloon(int initialX = 50, int initialY = 50, int initialDiameter = 20)
        {
            CreateEllipse();
            X = initialX;
            Y = initialY;
            Diameter = initialDiameter;
            count++;
            Name = $"ballon{count:D2}";
        
        }
        // methoden: eerst public methoden, dan de private methoden
        // methode om de kleur te wijzigen
        public void ChangeColor(Color color)
        {
            brush.Color = color;
        }
        public void MoveRight(int xStep)
        {
            X += xStep;
            //countMoveRight++; // indien geen autoproperty
            CountMoveRight++; // indien autoproperty
            // UpdateEllipse(); overbodig wordt in set van property X gedaan
        }

        public void ChangeSize(int change)
        {
            Diameter += change; // omwille van private get
        }

        public void DisplayOn(Canvas drawingCanvas)
        {
            drawingCanvas.Children.Add(ellipse);
        }

  

        private double CalculateArea()
        {
            double radius;
            radius = diameter / 2.0;
            return Math.PI * radius * radius;
        }

        private void CreateEllipse()
        {
            ellipse = new Ellipse()
            {
                Stroke = brush,
                StrokeThickness = 2
            };
        }

        private void UpdateEllipse()
        {
            ellipse.Margin = new Thickness(x, y, 0, 0);
            ellipse.Width = diameter;
            ellipse.Height = diameter;
        }
    }
}
