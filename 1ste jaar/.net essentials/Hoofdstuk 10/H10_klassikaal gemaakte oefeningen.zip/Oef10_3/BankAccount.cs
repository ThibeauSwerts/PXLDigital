﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oef10_3
{
    public class BankAccount
    {
        private int saldo;
        // read only property
        public int Saldo { get { return saldo; } }

        public void Withdraw(int amount)
        {
            saldo -= amount;
        }

        public void Deposit(int amount)
        {
            saldo += amount;
        }

    }
}
