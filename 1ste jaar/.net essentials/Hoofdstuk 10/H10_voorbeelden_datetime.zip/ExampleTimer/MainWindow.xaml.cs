﻿using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace ExampleTimer
{
   // vertrekkend van het voorbeeld uit H6 => pas de code aan 
   // 25 keer per seconde verschijnt er een cirkel
   // hoeveel tijd is er tussen het op de start en de stop button klikken uitgedrukt in ... seconden ... milliseconden
   // 2 manieren : stopwatch en ...
    public partial class MainWindow : Window
    {
        private Ellipse circle;
        // er elke seconde moet er een cirkel verschijnen nadat je op de drawButton geklikt hebt
        private DispatcherTimer timer;
        private Stopwatch stopwatch;// manier1
        private DateTime before; // manier2
      

        public MainWindow()
        {
            InitializeComponent();
            CreateEllipse();
            timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(1000/25) // snelheid waarmee timer tikt
            };
            timer.Tick += Timer_Tick;
            stopwatch = new Stopwatch();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            UpdateEllipse();
          
        }

        private void CreateEllipse()
        {
            circle = new Ellipse
            {   
                Stroke = new SolidColorBrush(Colors.Blue),
                Fill = new SolidColorBrush(Colors.Blue),
                Visibility = Visibility.Hidden
            };
            paperCanvas.Children.Add(circle);
          
        }

        private void UpdateEllipse()
        {
            Random random = new Random();
            // x, y van de linkerbovenhoek random genereren
            int x = random.Next(0, Convert.ToInt32(paperCanvas.Width));
            int y = random.Next(0, Convert.ToInt32(paperCanvas.Height));
            circle.Margin = new Thickness(x, y, 0, 0);
            // straal >=1 en <= 100 random genereren
            int diameter = random.Next(2, 201);
            circle.Width = diameter;
            circle.Height = diameter;

        }
        private void drawButton_Click(object sender, RoutedEventArgs e)
        {
            UpdateEllipse();
            circle.Visibility = Visibility.Visible;
            timer.Start();
            stopwatch.Start(); // manier1
            before = DateTime.Now; // manier2
        }

        private void removeButton_Click(object sender, RoutedEventArgs e)
        {
            circle.Visibility = Visibility.Hidden;
            timer.Stop();
            stopwatch.Stop();
            // bij stoppen van timer in MessageBox tonen ... seconden ... milliseconden tussen het starten en stoppen
            TimeSpan timeSpan = stopwatch.Elapsed;
           
            TimeSpan duration = DateTime.Now - before; // manier2
            MessageBox.Show($"het aantal seconden tussen start en stop manier1: {timeSpan.Seconds} sec {timeSpan.Milliseconds} \n" +
                $"manier2: {duration.Seconds} sec {duration.Milliseconds}");
        }
    }
}
