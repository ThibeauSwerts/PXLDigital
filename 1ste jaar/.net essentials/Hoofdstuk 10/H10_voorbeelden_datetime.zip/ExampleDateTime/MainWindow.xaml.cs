﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ExampleDateTime
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            MessageBox.Show("open eerst het outputvenster");
            DateTimeExamples();
        }

        private void DateTimeExamples()
        {
            // klasse DateTime
            // aanmaken van een datum (zonder tijd in werkelijkheid tijd 0:0:0)
            DateTime day1 = DateTime.Today;
            DateTime day2 = new DateTime(1999, 5, 27);
            DateTime day3 = Convert.ToDateTime("27/5/1999");
            DateTime day4 = DateTime.Parse("17/12/2020");
            DateTime day5 = day4.AddDays(1);  // 1 dag later
            // aanmaken van datum met tijd
            DateTime dayTime1 = DateTime.Now;
            DateTime dayTime2 = new DateTime(2000, 6, 12, 9, 5, 6);
            DateTime dayTime3 = Convert.ToDateTime("19/6/2000 12:5:16");
            DateTime dayTime4 = DateTime.Parse("20/05/20 15:05:06");
            DateTime dayTime5 = Convert.ToDateTime("15:05:6"); // datum staat op vandaag

            // afdrukken 
            // vb 6/03/2021 9:05:06
            Console.WriteLine(day1);
            Console.WriteLine(dayTime5);
            // vrijdag 5 mei 1999
            Console.WriteLine(day2.ToLongDateString());
            // vrijdag 05 mei 1999
            Console.WriteLine($"{day2:dddd dd MMMM yyyy}");
            // alleen de tijd afdrukken 2:05:16
            Console.WriteLine(dayTime2.ToLongTimeString());
            Console.WriteLine($"{dayTime2:hh:mm:ss}"); // 05:05:16
            // alleen de datum
            Console.WriteLine($"{dayTime2:d}");
            // alleen de tijd 12:05:16
            Console.WriteLine($"{dayTime2:T}");
            // alleen de tijd 12:05
            Console.WriteLine($"{dayTime2:t}");
            // 19/5/20 12:5:6
            Console.WriteLine($"{dayTime2:dd/M/yy h:m:s}");

            // alleen het jaar
            Console.WriteLine($"{day4.Year}");
            // alleen de dag in het Engels
            Console.WriteLine($"{day4.DayOfWeek}");
            // alleen de dag in het Nederlands
            Console.WriteLine($"{day4:dddd}");

            // rekenen met Datums
            // komt day4 voor day3
            Console.WriteLine("Komt dag4 voor dag3? {day4 < day3}");
            // tijdsduur tussen dayTime2 en day2
            TimeSpan timeSpan = dayTime2 - day2;
            // hiervan kan je dagen, uren min sec millisec opvragen geen jaren

            Console.WriteLine(timeSpan.Days); //382
            Console.WriteLine(timeSpan.TotalDays); //382, 3785...=> Chronounit Java
            Console.WriteLine(timeSpan.TotalHours); // 9177, 886
            Console.WriteLine(timeSpan.Hours); //9

            // tijd zonder datum of tijdsduur => klasse TimeSpan
            // tijdstip
            TimeSpan time1 = new TimeSpan(12, 10, 56);
            TimeSpan time2 = TimeSpan.Parse("12:5:54"); // Convert.ToTimeSpan bestaat niet!!!

            // tijdsduur van 1 seconde
            TimeSpan time3 = TimeSpan.FromSeconds(1);
            // tijdsduur tussen time1 en time2
            TimeSpan duration = time1.Subtract(time2);
            Console.WriteLine(duration); // -00:05:02
            // time1 seconden opvragen om nadien mee te rekenen
            Console.WriteLine(time1.Seconds);
            // time1 seconden opvragen er moet niet mee gerekend worden
            Console.WriteLine($"{time1:ss}"); // steeds ss gebruiken s werkt niet
            Console.WriteLine($"{time1:T}");
            Console.WriteLine($"{time1:hh\\:mm\\:ss}");

            // tijd opmeten
            DateTime before = DateTime.Now;
            DateTime after = DateTime.Now;
            TimeSpan duration1 = after - before;
            Console.WriteLine(duration1.TotalMilliseconds); // deze oplossing werkt niet nauwkeurig

            // alternatief maar nauwkeuriger
            Stopwatch stopwatch = new Stopwatch(); // vergelijk met een chronometer
            stopwatch.Start();
            stopwatch.Stop();
            TimeSpan duration2 = stopwatch.Elapsed;
            Console.WriteLine(duration2.TotalMilliseconds);

        }
    }
}
