﻿using System;
using System.IO;

namespace Pick
{
    public class Program
    {
        public static void Main(string[] args)
        {
            string fileName = args[0];
            Console.Write($"We zoeken in bestand {fileName}");
            string wanted = args[1];
            Console.WriteLine($" naar {wanted}");
            StreamReader reader = File.OpenText(fileName);
            string line = reader.ReadLine();
            while (line != null)
            {
                if (line.IndexOf(wanted) >= 0)
                {
                    Console.WriteLine(line);
                }
                line = reader.ReadLine();
            }
            reader.Close();
            Console.ReadLine();
        }
    }
}
