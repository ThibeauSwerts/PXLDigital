﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace TriangleMethods
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void drawButton_Click(object sender, RoutedEventArgs e)
        {
            
            SolidColorBrush brushToUse = new SolidColorBrush(Colors.Black);
            drawTriangle(paperCanvas, brushToUse, 20, 70, 120, 80, 10, 80);
            
        }
        private void drawLine(Canvas drawingArea, SolidColorBrush color,
            int startx, int starty, int endx, int endy)
        {
            Line line = new Line();
            line.X1 = startx;
            line.Y1 = starty;
            line.X2 = endx;
            line.Y2 = endy;
            line.Stroke = color;
            drawingArea.Children.Add(line);
        }
        private void drawTriangle(Canvas drawingArea, SolidColorBrush color,
            int x1, int x2, int x3, int y1, int y2, int y3)
        {
            drawLine(drawingArea, color, x1, y1, x2, y2);
            drawLine(drawingArea, color, x2, y2, x3, y3);
            drawLine(drawingArea, color, x3, y3, x1, y1);
        }
    }
}
