﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Example
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, RoutedEventArgs e)
        {
            int cents = Convert.ToInt32(inputTextBox.Text);

            // output1TextBlock.Text = $"{cents/100} euros and {cents%100} cents";
            // voorzie 7 posities voor de euros links uitgelijnd, 5 posities voor de cents rechts uitgelijnd
            //output1TextBlock.Text = $"{cents/100, -7} euros and {cents%100, 5} cents";
            // voozie 8 posities voor euros eventueel opgevuld met voorloopnullen
            output1TextBlock.Text = $"{cents/100:D8} euros and {cents%100} cents";
            //output2TextBlock.Text = $"{cents/100.0:C}"; // met 2 decimalen
            // met 1  decimaal
            output2TextBlock.Text = $"{cents/100.0:C1}"; 
        }
    }
}
